package com.programming_simplified.movieapp.features.movies.domain.model

import com.programming_simplified.movieapp.data.model.Movies

data class MovieUiModel(
    val results:Movies.Results
)
