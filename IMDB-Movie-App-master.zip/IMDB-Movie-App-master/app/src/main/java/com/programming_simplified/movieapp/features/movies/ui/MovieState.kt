package com.programming_simplified.movieapp.features.movies.ui

import com.programming_simplified.movieapp.data.model.Movies
import com.programming_simplified.movieapp.features.movies.domain.model.MovieUiModel

data class MovieState(
    val data:List<MovieUiModel>? = emptyList(),
    val error:String = "",
    val isLoading:Boolean = false
)
