A list of benchmarks to measure the different aspects of Riverpod

To run a benchmark, run:

```sh
flutter run --release -t lib/some_benchmark.dart
```
