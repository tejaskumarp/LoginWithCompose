The standard Flutter Counter example built with [Riverpod]

This uses `ProviderScope`.


[riverpod]: https://github.com/rrousselGit/riverpod
