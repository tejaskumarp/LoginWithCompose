A StackOverflow client implemented using Riverpod and the official StackOverflow API

The example is still in progress

# Setup

This example uses code generation.
Before starting the application, you must first start the code generators.

This can be done with:

```sh
cd examples/stackoverflow
dart run build_runner build -d
```
