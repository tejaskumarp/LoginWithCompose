A todo-list built with [Riverpod]

This showcase slightly more advanced state manipulation, using [Computed].

<img alt="todo screenshot" src="https://github.com/rrousselGit/riverpod/blob/master/examples/todos/todo_screenshot.jpg" width="400px">


[riverpod]: https://github.com/rrousselGit/riverpod
