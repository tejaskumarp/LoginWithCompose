// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'provider_parameters.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$FreezedExample {}

/// @nodoc
abstract class $FreezedExampleCopyWith<$Res> {
  factory $FreezedExampleCopyWith(
          FreezedExample value, $Res Function(FreezedExample) then) =
      _$FreezedExampleCopyWithImpl<$Res, FreezedExample>;
}

/// @nodoc
class _$FreezedExampleCopyWithImpl<$Res, $Val extends FreezedExample>
    implements $FreezedExampleCopyWith<$Res> {
  _$FreezedExampleCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of FreezedExample
  /// with the given fields replaced by the non-null parameter values.
}

/// @nodoc
abstract class _$$FreezedExampleImplCopyWith<$Res> {
  factory _$$FreezedExampleImplCopyWith(_$FreezedExampleImpl value,
          $Res Function(_$FreezedExampleImpl) then) =
      __$$FreezedExampleImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$FreezedExampleImplCopyWithImpl<$Res>
    extends _$FreezedExampleCopyWithImpl<$Res, _$FreezedExampleImpl>
    implements _$$FreezedExampleImplCopyWith<$Res> {
  __$$FreezedExampleImplCopyWithImpl(
      _$FreezedExampleImpl _value, $Res Function(_$FreezedExampleImpl) _then)
      : super(_value, _then);

  /// Create a copy of FreezedExample
  /// with the given fields replaced by the non-null parameter values.
}

/// @nodoc

class _$FreezedExampleImpl implements _FreezedExample {
  _$FreezedExampleImpl();

  @override
  String toString() {
    return 'FreezedExample()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$FreezedExampleImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;
}

abstract class _FreezedExample implements FreezedExample {
  factory _FreezedExample() = _$FreezedExampleImpl;
}
