// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dependencies.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$unimplementedScopedHash() =>
    r'5f32fc56f4157238612d62ef54038fe92b7cdfe8';

/// See also [unimplementedScoped].
@ProviderFor(unimplementedScoped)
final unimplementedScopedProvider = AutoDisposeProvider<int>.internal(
  (_) => throw UnsupportedError(
    'The provider "unimplementedScopedProvider" is expected to get overridden/scoped, '
    'but was accessed without an override.',
  ),
  name: r'unimplementedScopedProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$unimplementedScopedHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef UnimplementedScopedRef = AutoDisposeProviderRef<int>;
String _$depHash() => r'749c4d696d29c72686cabcabd6fa7855f5cbf4db';

/// See also [dep].
@ProviderFor(dep)
final depProvider = AutoDisposeProvider<int>.internal(
  dep,
  name: r'depProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$depHash,
  dependencies: const <ProviderOrFamily>[],
  allTransitiveDependencies: const <ProviderOrFamily>{},
);

typedef DepRef = AutoDisposeProviderRef<int>;
String _$generatedScopedHash() => r'2eefb4cc872ddccfeb862142fd5f7e6d8bd82159';

/// See also [generatedScoped].
@ProviderFor(generatedScoped)
final generatedScopedProvider = AutoDisposeProvider<int>.internal(
  generatedScoped,
  name: r'generatedScopedProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$generatedScopedHash,
  dependencies: const <ProviderOrFamily>[],
  allTransitiveDependencies: const <ProviderOrFamily>{},
);

typedef GeneratedScopedRef = AutoDisposeProviderRef<int>;
String _$generatedRootHash() => r'080e3393566db0f44add3607e28a5a2980948704';

/// See also [generatedRoot].
@ProviderFor(generatedRoot)
final generatedRootProvider = AutoDisposeProvider<int>.internal(
  generatedRoot,
  name: r'generatedRootProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$generatedRootHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef GeneratedRootRef = AutoDisposeProviderRef<int>;
String _$watchScopedButNoDependenciesHash() =>
    r'3ec52c4ab2ea2b3204b7aa049d1756c01c014ff0';

/// See also [watchScopedButNoDependencies].
@ProviderFor(watchScopedButNoDependencies)
final watchScopedButNoDependenciesProvider = AutoDisposeProvider<int>.internal(
  watchScopedButNoDependencies,
  name: r'watchScopedButNoDependenciesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$watchScopedButNoDependenciesHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef WatchScopedButNoDependenciesRef = AutoDisposeProviderRef<int>;
String _$watchExternalButNoDependenciesHash() =>
    r'bbe1ed12645a261e2030222549308d378f5f368c';

/// See also [watchExternalButNoDependencies].
@ProviderFor(watchExternalButNoDependencies)
final watchExternalButNoDependenciesProvider =
    AutoDisposeProvider<int>.internal(
  watchExternalButNoDependencies,
  name: r'watchExternalButNoDependenciesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$watchExternalButNoDependenciesHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef WatchExternalButNoDependenciesRef = AutoDisposeProviderRef<int>;
String _$watchGeneratedScopedButNoDependenciesHash() =>
    r'2a4aba824078fe2c999260b4138939dee96c4fba';

/// See also [watchGeneratedScopedButNoDependencies].
@ProviderFor(watchGeneratedScopedButNoDependencies)
final watchGeneratedScopedButNoDependenciesProvider =
    AutoDisposeProvider<int>.internal(
  watchGeneratedScopedButNoDependencies,
  name: r'watchGeneratedScopedButNoDependenciesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$watchGeneratedScopedButNoDependenciesHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef WatchGeneratedScopedButNoDependenciesRef = AutoDisposeProviderRef<int>;
String _$watchRootButNoDependenciesHash() =>
    r'037187e333a5bd5d11d00147d179640b8a0f18dd';

/// See also [watchRootButNoDependencies].
@ProviderFor(watchRootButNoDependencies)
final watchRootButNoDependenciesProvider = AutoDisposeProvider<int>.internal(
  watchRootButNoDependencies,
  name: r'watchRootButNoDependenciesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$watchRootButNoDependenciesHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef WatchRootButNoDependenciesRef = AutoDisposeProviderRef<int>;
String _$watchGeneratedRootButNoDependenciesHash() =>
    r'ecf43cc257376d2828638ce937813d2b72b46967';

/// See also [watchGeneratedRootButNoDependencies].
@ProviderFor(watchGeneratedRootButNoDependencies)
final watchGeneratedRootButNoDependenciesProvider =
    AutoDisposeProvider<int>.internal(
  watchGeneratedRootButNoDependencies,
  name: r'watchGeneratedRootButNoDependenciesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$watchGeneratedRootButNoDependenciesHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef WatchGeneratedRootButNoDependenciesRef = AutoDisposeProviderRef<int>;
String _$watchScopedButEmptyDependenciesHash() =>
    r'6b7526eb9dfd70c8249c71efffc60d612ca92f16';

/// See also [watchScopedButEmptyDependencies].
@ProviderFor(watchScopedButEmptyDependencies)
final watchScopedButEmptyDependenciesProvider =
    AutoDisposeProvider<int>.internal(
  watchScopedButEmptyDependencies,
  name: r'watchScopedButEmptyDependenciesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$watchScopedButEmptyDependenciesHash,
  dependencies: const <ProviderOrFamily>[],
  allTransitiveDependencies: const <ProviderOrFamily>{},
);

typedef WatchScopedButEmptyDependenciesRef = AutoDisposeProviderRef<int>;
String _$watchGeneratedScopedButEmptyDependenciesHash() =>
    r'5dc6791ab2f661a378de3e8335943a48e8305435';

/// See also [watchGeneratedScopedButEmptyDependencies].
@ProviderFor(watchGeneratedScopedButEmptyDependencies)
final watchGeneratedScopedButEmptyDependenciesProvider =
    AutoDisposeProvider<int>.internal(
  watchGeneratedScopedButEmptyDependencies,
  name: r'watchGeneratedScopedButEmptyDependenciesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$watchGeneratedScopedButEmptyDependenciesHash,
  dependencies: const <ProviderOrFamily>[],
  allTransitiveDependencies: const <ProviderOrFamily>{},
);

typedef WatchGeneratedScopedButEmptyDependenciesRef
    = AutoDisposeProviderRef<int>;
String _$watchRootButEmptyDependenciesHash() =>
    r'c95800f6aec446737168ac8dc3e6edcaeeed3bc0';

/// See also [watchRootButEmptyDependencies].
@ProviderFor(watchRootButEmptyDependencies)
final watchRootButEmptyDependenciesProvider = AutoDisposeProvider<int>.internal(
  watchRootButEmptyDependencies,
  name: r'watchRootButEmptyDependenciesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$watchRootButEmptyDependenciesHash,
  dependencies: const <ProviderOrFamily>[],
  allTransitiveDependencies: const <ProviderOrFamily>{},
);

typedef WatchRootButEmptyDependenciesRef = AutoDisposeProviderRef<int>;
String _$watchGeneratedRootButEmptyDependenciesHash() =>
    r'9fb97c1fa207a18870cd23c682305dcef413a706';

/// See also [watchGeneratedRootButEmptyDependencies].
@ProviderFor(watchGeneratedRootButEmptyDependencies)
final watchGeneratedRootButEmptyDependenciesProvider =
    AutoDisposeProvider<int>.internal(
  watchGeneratedRootButEmptyDependencies,
  name: r'watchGeneratedRootButEmptyDependenciesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$watchGeneratedRootButEmptyDependenciesHash,
  dependencies: const <ProviderOrFamily>[],
  allTransitiveDependencies: const <ProviderOrFamily>{},
);

typedef WatchGeneratedRootButEmptyDependenciesRef = AutoDisposeProviderRef<int>;
String _$watchScopedButMissingDependenciesHash() =>
    r'9bc337d57438161120d179de48443ed4be4c5b65';

/// See also [watchScopedButMissingDependencies].
@ProviderFor(watchScopedButMissingDependencies)
final watchScopedButMissingDependenciesProvider =
    AutoDisposeProvider<int>.internal(
  watchScopedButMissingDependencies,
  name: r'watchScopedButMissingDependenciesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$watchScopedButMissingDependenciesHash,
  dependencies: <ProviderOrFamily>[depProvider],
  allTransitiveDependencies: <ProviderOrFamily>{
    depProvider,
    ...?depProvider.allTransitiveDependencies
  },
);

typedef WatchScopedButMissingDependenciesRef = AutoDisposeProviderRef<int>;
String _$watchGeneratedScopedButMissingDependenciesHash() =>
    r'be4cf146ec2bebf4c92f6acd73e1dee60e689c20';

/// See also [watchGeneratedScopedButMissingDependencies].
@ProviderFor(watchGeneratedScopedButMissingDependencies)
final watchGeneratedScopedButMissingDependenciesProvider =
    AutoDisposeProvider<int>.internal(
  watchGeneratedScopedButMissingDependencies,
  name: r'watchGeneratedScopedButMissingDependenciesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$watchGeneratedScopedButMissingDependenciesHash,
  dependencies: <ProviderOrFamily>[depProvider],
  allTransitiveDependencies: <ProviderOrFamily>{
    depProvider,
    ...?depProvider.allTransitiveDependencies
  },
);

typedef WatchGeneratedScopedButMissingDependenciesRef
    = AutoDisposeProviderRef<int>;
String _$watchRootButMissingDependenciesHash() =>
    r'aa6ca4efaba18ad3d2132439f1bb26773cceb170';

/// See also [watchRootButMissingDependencies].
@ProviderFor(watchRootButMissingDependencies)
final watchRootButMissingDependenciesProvider =
    AutoDisposeProvider<int>.internal(
  watchRootButMissingDependencies,
  name: r'watchRootButMissingDependenciesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$watchRootButMissingDependenciesHash,
  dependencies: <ProviderOrFamily>[depProvider],
  allTransitiveDependencies: <ProviderOrFamily>{
    depProvider,
    ...?depProvider.allTransitiveDependencies
  },
);

typedef WatchRootButMissingDependenciesRef = AutoDisposeProviderRef<int>;
String _$watchGeneratedRootButMissingDependenciesHash() =>
    r'eda2f1b9c3aaf26cd152108104b8bbb71774c906';

/// See also [watchGeneratedRootButMissingDependencies].
@ProviderFor(watchGeneratedRootButMissingDependencies)
final watchGeneratedRootButMissingDependenciesProvider =
    AutoDisposeProvider<int>.internal(
  watchGeneratedRootButMissingDependencies,
  name: r'watchGeneratedRootButMissingDependenciesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$watchGeneratedRootButMissingDependenciesHash,
  dependencies: <ProviderOrFamily>[depProvider],
  allTransitiveDependencies: <ProviderOrFamily>{
    depProvider,
    ...?depProvider.allTransitiveDependencies
  },
);

typedef WatchGeneratedRootButMissingDependenciesRef
    = AutoDisposeProviderRef<int>;
String _$watchGeneratedScopedAndContainsDependencyHash() =>
    r'320592737e763091c1229a79ae07fe961e7aab72';

/// See also [watchGeneratedScopedAndContainsDependency].
@ProviderFor(watchGeneratedScopedAndContainsDependency)
final watchGeneratedScopedAndContainsDependencyProvider =
    AutoDisposeProvider<int>.internal(
  watchGeneratedScopedAndContainsDependency,
  name: r'watchGeneratedScopedAndContainsDependencyProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$watchGeneratedScopedAndContainsDependencyHash,
  dependencies: <ProviderOrFamily>[generatedScopedProvider],
  allTransitiveDependencies: <ProviderOrFamily>{
    generatedScopedProvider,
    ...?generatedScopedProvider.allTransitiveDependencies
  },
);

typedef WatchGeneratedScopedAndContainsDependencyRef
    = AutoDisposeProviderRef<int>;
String _$watchGeneratedRootAndContainsDependencyHash() =>
    r'5bb8cc73e375ce8c5dbd03d5ca3c16fb2d5b199f';

/// See also [watchGeneratedRootAndContainsDependency].
@ProviderFor(watchGeneratedRootAndContainsDependency)
final watchGeneratedRootAndContainsDependencyProvider =
    AutoDisposeProvider<int>.internal(
  watchGeneratedRootAndContainsDependency,
  name: r'watchGeneratedRootAndContainsDependencyProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$watchGeneratedRootAndContainsDependencyHash,
  dependencies: <ProviderOrFamily>[generatedRootProvider],
  allTransitiveDependencies: <ProviderOrFamily>{
    generatedRootProvider,
    ...?generatedRootProvider.allTransitiveDependencies
  },
);

typedef WatchGeneratedRootAndContainsDependencyRef
    = AutoDisposeProviderRef<int>;
String _$specifiedDependencyButNeverUsedHash() =>
    r'b0254ee8c3a0360ec249686083f430b12f3b4940';

/// See also [specifiedDependencyButNeverUsed].
@ProviderFor(specifiedDependencyButNeverUsed)
final specifiedDependencyButNeverUsedProvider =
    AutoDisposeProvider<int>.internal(
  specifiedDependencyButNeverUsed,
  name: r'specifiedDependencyButNeverUsedProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$specifiedDependencyButNeverUsedHash,
  dependencies: <ProviderOrFamily>[depProvider, generatedRootProvider],
  allTransitiveDependencies: <ProviderOrFamily>{
    depProvider,
    ...?depProvider.allTransitiveDependencies,
    generatedRootProvider,
    ...?generatedRootProvider.allTransitiveDependencies
  },
);

typedef SpecifiedDependencyButNeverUsedRef = AutoDisposeProviderRef<int>;
String _$regression2348Hash() => r'72fbbe420e9835c9843c28b7c9375ca3d99ca4b7';

/// See also [regression2348].
@ProviderFor(regression2348)
final regression2348Provider = AutoDisposeProvider<int>.internal(
  regression2348,
  name: r'regression2348Provider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$regression2348Hash,
  dependencies: <ProviderOrFamily>[generatedScopedProvider],
  allTransitiveDependencies: <ProviderOrFamily>{
    generatedScopedProvider,
    ...?generatedScopedProvider.allTransitiveDependencies
  },
);

typedef Regression2348Ref = AutoDisposeProviderRef<int>;
String _$familyDepHash() => r'1c152873ed2b3e88da09d8e1fc53a33635cbe3b3';

/// Copied from Dart SDK
class _SystemHash {
  _SystemHash._();

  static int combine(int hash, int value) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + value);
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x0007ffff & hash) << 10));
    return hash ^ (hash >> 6);
  }

  static int finish(int hash) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x03ffffff & hash) << 3));
    // ignore: parameter_assignments
    hash = hash ^ (hash >> 11);
    return 0x1fffffff & (hash + ((0x00003fff & hash) << 15));
  }
}

/// See also [familyDep].
@ProviderFor(familyDep)
const familyDepProvider = FamilyDepFamily();

/// See also [familyDep].
class FamilyDepFamily extends Family<int> {
  /// See also [familyDep].
  const FamilyDepFamily();

  /// See also [familyDep].
  FamilyDepProvider call(
    int p,
  ) {
    return FamilyDepProvider(
      p,
    );
  }

  @override
  FamilyDepProvider getProviderOverride(
    covariant FamilyDepProvider provider,
  ) {
    return call(
      provider.p,
    );
  }

  static final Iterable<ProviderOrFamily> _dependencies = <ProviderOrFamily>[
    depProvider
  ];

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static final Iterable<ProviderOrFamily> _allTransitiveDependencies =
      <ProviderOrFamily>{
    depProvider,
    ...?depProvider.allTransitiveDependencies
  };

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'familyDepProvider';
}

/// See also [familyDep].
class FamilyDepProvider extends AutoDisposeProvider<int> {
  /// See also [familyDep].
  FamilyDepProvider(
    int p,
  ) : this._internal(
          (ref) => familyDep(
            ref as FamilyDepRef,
            p,
          ),
          from: familyDepProvider,
          name: r'familyDepProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$familyDepHash,
          dependencies: FamilyDepFamily._dependencies,
          allTransitiveDependencies: FamilyDepFamily._allTransitiveDependencies,
          p: p,
        );

  FamilyDepProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.p,
  }) : super.internal();

  final int p;

  @override
  Override overrideWith(
    int Function(FamilyDepRef provider) create,
  ) {
    return ProviderOverride(
      origin: this,
      override: FamilyDepProvider._internal(
        (ref) => create(ref as FamilyDepRef),
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        p: p,
      ),
    );
  }

  @override
  AutoDisposeProviderElement<int> createElement() {
    return _FamilyDepProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is FamilyDepProvider && other.p == p;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, p.hashCode);

    return _SystemHash.finish(hash);
  }
}

mixin FamilyDepRef on AutoDisposeProviderRef<int> {
  /// The parameter `p` of this provider.
  int get p;
}

class _FamilyDepProviderElement extends AutoDisposeProviderElement<int>
    with FamilyDepRef {
  _FamilyDepProviderElement(super.provider);

  @override
  int get p => (origin as FamilyDepProvider).p;
}

String _$familyDep2Hash() => r'd81e2e56d75dd08a695b834853a3a6cea99ea305';

/// See also [familyDep2].
@ProviderFor(familyDep2)
const familyDep2Provider = FamilyDep2Family();

/// See also [familyDep2].
class FamilyDep2Family extends Family<int> {
  /// See also [familyDep2].
  const FamilyDep2Family();

  /// See also [familyDep2].
  FamilyDep2Provider call(
    int p,
  ) {
    return FamilyDep2Provider(
      p,
    );
  }

  @override
  FamilyDep2Provider getProviderOverride(
    covariant FamilyDep2Provider provider,
  ) {
    return call(
      provider.p,
    );
  }

  static final Iterable<ProviderOrFamily> _dependencies = <ProviderOrFamily>[
    familyDepProvider
  ];

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static final Iterable<ProviderOrFamily> _allTransitiveDependencies =
      <ProviderOrFamily>{
    familyDepProvider,
    ...?familyDepProvider.allTransitiveDependencies
  };

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'familyDep2Provider';
}

/// See also [familyDep2].
class FamilyDep2Provider extends AutoDisposeProvider<int> {
  /// See also [familyDep2].
  FamilyDep2Provider(
    int p,
  ) : this._internal(
          (ref) => familyDep2(
            ref as FamilyDep2Ref,
            p,
          ),
          from: familyDep2Provider,
          name: r'familyDep2Provider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$familyDep2Hash,
          dependencies: FamilyDep2Family._dependencies,
          allTransitiveDependencies:
              FamilyDep2Family._allTransitiveDependencies,
          p: p,
        );

  FamilyDep2Provider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.p,
  }) : super.internal();

  final int p;

  @override
  Override overrideWith(
    int Function(FamilyDep2Ref provider) create,
  ) {
    return ProviderOverride(
      origin: this,
      override: FamilyDep2Provider._internal(
        (ref) => create(ref as FamilyDep2Ref),
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        p: p,
      ),
    );
  }

  @override
  AutoDisposeProviderElement<int> createElement() {
    return _FamilyDep2ProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is FamilyDep2Provider && other.p == p;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, p.hashCode);

    return _SystemHash.finish(hash);
  }
}

mixin FamilyDep2Ref on AutoDisposeProviderRef<int> {
  /// The parameter `p` of this provider.
  int get p;
}

class _FamilyDep2ProviderElement extends AutoDisposeProviderElement<int>
    with FamilyDep2Ref {
  _FamilyDep2ProviderElement(super.provider);

  @override
  int get p => (origin as FamilyDep2Provider).p;
}

String _$aliasHash() => r'871c6c7ab22e4bbed2dc46917daf42e7fc1b9d88';

/// See also [alias].
@ProviderFor(alias)
final aliasProvider = AutoDisposeProvider<int>.internal(
  alias,
  name: r'aliasProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$aliasHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef AliasRef = AutoDisposeProviderRef<int>;
String _$classWatchGeneratedRootButMissingDependenciesHash() =>
    r'e36d7126a86ea9ded6dc66a6f33eabb2724455a9';

/// See also [ClassWatchGeneratedRootButMissingDependencies].
@ProviderFor(ClassWatchGeneratedRootButMissingDependencies)
final classWatchGeneratedRootButMissingDependenciesProvider =
    AutoDisposeNotifierProvider<ClassWatchGeneratedRootButMissingDependencies,
        int>.internal(
  ClassWatchGeneratedRootButMissingDependencies.new,
  name: r'classWatchGeneratedRootButMissingDependenciesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$classWatchGeneratedRootButMissingDependenciesHash,
  dependencies: const <ProviderOrFamily>[],
  allTransitiveDependencies: const <ProviderOrFamily>{},
);

typedef _$ClassWatchGeneratedRootButMissingDependencies
    = AutoDisposeNotifier<int>;
String _$classWatchGeneratedScopedButMissingDependenciesHash() =>
    r'f5a5ba5f572ee2d0654c89de9e991cef9f15b936';

/// See also [ClassWatchGeneratedScopedButMissingDependencies].
@ProviderFor(ClassWatchGeneratedScopedButMissingDependencies)
final classWatchGeneratedScopedButMissingDependenciesProvider =
    AutoDisposeNotifierProvider<ClassWatchGeneratedScopedButMissingDependencies,
        int>.internal(
  ClassWatchGeneratedScopedButMissingDependencies.new,
  name: r'classWatchGeneratedScopedButMissingDependenciesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$classWatchGeneratedScopedButMissingDependenciesHash,
  dependencies: const <ProviderOrFamily>[],
  allTransitiveDependencies: const <ProviderOrFamily>{},
);

typedef _$ClassWatchGeneratedScopedButMissingDependencies
    = AutoDisposeNotifier<int>;
String _$regression2417Hash() => r'c9ac0ba44e849ea1460c79c1f676feba1b5400da';

/// See also [Regression2417].
@ProviderFor(Regression2417)
final regression2417Provider =
    AutoDisposeNotifierProvider<Regression2417, int>.internal(
  Regression2417.new,
  name: r'regression2417Provider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$regression2417Hash,
  dependencies: <ProviderOrFamily>[generatedScopedProvider],
  allTransitiveDependencies: <ProviderOrFamily>{
    generatedScopedProvider,
    ...?generatedScopedProvider.allTransitiveDependencies
  },
);

typedef _$Regression2417 = AutoDisposeNotifier<int>;
String _$aliasClassHash() => r'f5c1f43e7541638274ca7dc334a713763c9c8071';

/// See also [AliasClass].
@ProviderFor(AliasClass)
final aliasClassProvider =
    AutoDisposeNotifierProvider<AliasClass, int>.internal(
  AliasClass.new,
  name: r'aliasClassProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$aliasClassHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AliasClass = AutoDisposeNotifier<int>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
