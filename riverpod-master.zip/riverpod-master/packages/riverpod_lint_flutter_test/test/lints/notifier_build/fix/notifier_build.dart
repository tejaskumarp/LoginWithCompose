import 'package:riverpod_annotation/riverpod_annotation.dart';

/// Fake Provider
typedef _$ExampleProvider1 = Object;

@riverpod
// expect_lint: notifier_build
class ExampleProvider1 extends _$ExampleProvider1 {}
