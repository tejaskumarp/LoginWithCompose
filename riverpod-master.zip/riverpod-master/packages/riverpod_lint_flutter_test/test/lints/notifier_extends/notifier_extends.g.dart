// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'notifier_extends.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$myNotifierHash() => r'58f5439a3b1036ba7804f63a5a6ebe0114125039';

/// See also [MyNotifier].
@ProviderFor(MyNotifier)
final myNotifierProvider =
    AutoDisposeNotifierProvider<MyNotifier, int>.internal(
  MyNotifier.new,
  name: r'myNotifierProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$myNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$MyNotifier = AutoDisposeNotifier<int>;
String _$noExtendsHash() => r'3f1276999a9a6d3676c628c25ed853cbefb21ce9';

/// See also [NoExtends].
@ProviderFor(NoExtends)
final noExtendsProvider = AutoDisposeNotifierProvider<NoExtends, int>.internal(
  NoExtends.new,
  name: r'noExtendsProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$noExtendsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$NoExtends = AutoDisposeNotifier<int>;
String _$wrongExtendsHash() => r'6479055793af10a34e225373a67f7eaac4d7c0de';

/// See also [WrongExtends].
@ProviderFor(WrongExtends)
final wrongExtendsProvider =
    AutoDisposeNotifierProvider<WrongExtends, int>.internal(
  WrongExtends.new,
  name: r'wrongExtendsProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$wrongExtendsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$WrongExtends = AutoDisposeNotifier<int>;
String _$privateClassHash() => r'ba68a29a609566bb8bc0792391f842762356e124';

/// See also [_PrivateClass].
@ProviderFor(_PrivateClass)
final _privateClassProvider =
    AutoDisposeNotifierProvider<_PrivateClass, String>.internal(
  _PrivateClass.new,
  name: r'_privateClassProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$privateClassHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$PrivateClass = AutoDisposeNotifier<String>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
