// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'another.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$bHash() => r'52593050701642f22b31c590f20c003dc2ee1579';

/// See also [b].
@ProviderFor(b)
final bProvider = AutoDisposeProvider<int>.internal(
  b,
  name: r'bProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$bHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef BRef = AutoDisposeProviderRef<int>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
