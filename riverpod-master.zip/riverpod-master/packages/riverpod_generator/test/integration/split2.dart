part of 'split.dart';

@riverpod
int counter(CounterRef ref) => 0;
