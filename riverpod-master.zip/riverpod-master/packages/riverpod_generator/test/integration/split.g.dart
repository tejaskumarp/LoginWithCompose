// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'split.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$counter2Hash() => r'9328919066a683f85226fc59201bb7c54f107a7d';

/// See also [counter2].
@ProviderFor(counter2)
final counter2Provider = AutoDisposeProvider<int>.internal(
  counter2,
  name: r'counter2Provider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$counter2Hash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef Counter2Ref = AutoDisposeProviderRef<int>;
String _$counterHash() => r'9b0db44ecc47057e79891e5ecd92d34b08637679';

/// See also [counter].
@ProviderFor(counter)
final counterProvider = AutoDisposeProvider<int>.internal(
  counter,
  name: r'counterProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$counterHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef CounterRef = AutoDisposeProviderRef<int>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
