// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'hash1.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$simpleHash() => r'ff9f7451526aef5b3af6646814631a502ad76a5f';

/// See also [simple].
@ProviderFor(simple)
final simpleProvider = AutoDisposeProvider<String>.internal(
  simple,
  name: r'simpleProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$simpleHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef SimpleRef = AutoDisposeProviderRef<String>;
String _$simple2Hash() => r'06327442776394c5c9cbb33b048d7a42e709e7fd';

/// See also [simple2].
@ProviderFor(simple2)
final simple2Provider = AutoDisposeProvider<String>.internal(
  simple2,
  name: r'simple2Provider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$simple2Hash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef Simple2Ref = AutoDisposeProviderRef<String>;
String _$simpleClassHash() => r'958123cd6179c5b88da040cfeb71eb3061765277';

/// See also [SimpleClass].
@ProviderFor(SimpleClass)
final simpleClassProvider =
    AutoDisposeNotifierProvider<SimpleClass, String>.internal(
  SimpleClass.new,
  name: r'simpleClassProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$simpleClassHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$SimpleClass = AutoDisposeNotifier<String>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
