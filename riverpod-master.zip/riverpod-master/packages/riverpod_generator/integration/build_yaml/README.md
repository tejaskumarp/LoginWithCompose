# Pub

Install needed global packages

```bash
cd riverpod
dart pub global activate melos
```

Build the riverpod packages

```bash
fluttter pub get
```

## Start the tests

```bash
cd examples/build_yaml
dart run build_runner build

flutter test
```
