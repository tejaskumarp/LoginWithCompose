abstract class Template {
  void run(StringBuffer buffer);
}
