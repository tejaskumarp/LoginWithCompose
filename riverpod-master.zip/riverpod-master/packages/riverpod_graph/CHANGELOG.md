## 0.0.2 - 2023-08-03

Support analyzer 6.0.0
