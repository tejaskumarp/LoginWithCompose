A package internal to Riverpod, used to parse providers using the analyzer.
