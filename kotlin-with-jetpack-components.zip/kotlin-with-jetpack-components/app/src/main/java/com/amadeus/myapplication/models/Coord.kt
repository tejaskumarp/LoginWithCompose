package com.amadeus.myapplication.models

data class Coord(
    val lat: Double=0.0,
    val lon: Double=0.0
)