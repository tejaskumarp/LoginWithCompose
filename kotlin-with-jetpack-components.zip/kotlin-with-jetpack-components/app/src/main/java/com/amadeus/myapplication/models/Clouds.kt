package com.amadeus.myapplication.models

data class Clouds(
    val all: Int=0
)