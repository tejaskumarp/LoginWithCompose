# :core:database module

![Dependency graph](../../docs/images/graphs/dep_graph_core_database.png)
