# :core:data module

![Dependency graph](../../docs/images/graphs/dep_graph_core_data.png)
