# :core:model module

![Dependency graph](../../docs/images/graphs/dep_graph_core_model.png)
