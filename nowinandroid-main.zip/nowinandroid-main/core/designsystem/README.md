# :core:designsystem module

![Dependency graph](../../docs/images/graphs/dep_graph_core_designsystem.png)
