# :core:data-test module

![Dependency graph](../../docs/images/graphs/dep_graph_core_data_test.png)
