# :feature:bookmarks module

![Dependency graph](../../docs/images/graphs/dep_graph_feature_bookmarks.png)
