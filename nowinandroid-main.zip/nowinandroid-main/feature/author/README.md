# :feature:author module

![Dependency graph](../../docs/images/graphs/dep_graph_feature_author.png)
