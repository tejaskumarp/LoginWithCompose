# :feature:foryou module

![Dependency graph](../../docs/images/graphs/dep_graph_feature_foryou.png)
